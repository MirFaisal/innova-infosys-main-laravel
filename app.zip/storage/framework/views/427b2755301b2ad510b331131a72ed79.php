<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__("Dashboard")); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div
                        class="overflow-x-auto rounded-lg border border-gray-200"
                    >
                        <table
                            class="min-w-full divide-y-2 divide-gray-200 bg-white text-sm"
                        >
                            <thead
                                class="ltr:text-left rtl:text-right text-center"
                            >
                                <tr>
                                    <th
                                        class="whitespace-nowrap px-4 py-2 font-medium text-gray-900"
                                    >
                                        SN
                                    </th>
                                    <th
                                        class="whitespace-nowrap px-4 py-2 font-medium text-gray-900"
                                    >
                                        Name
                                    </th>
                                    <th
                                        class="whitespace-nowrap px-4 py-2 font-medium text-gray-900"
                                    >
                                        Send at
                                    </th>
                                    <th
                                        class="whitespace-nowrap px-4 py-2 font-medium text-gray-900"
                                    >
                                        Email
                                    </th>
                                    <th
                                        class="whitespace-nowrap px-4 py-2 font-medium text-gray-900"
                                    >
                                        Message
                                    </th>
                                </tr>
                            </thead>

                            <tbody class="divide-y divide-gray-200 text-center">
                                <?php $__currentLoopData = $allMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="cursor-pointer">
                                    <td
                                        class="whitespace-nowrap px-4 py-2 font-medium text-gray-900"
                                    >
                                        <?php echo e($key + 1); ?>

                                    </td>
                                    <td
                                        class="whitespace-nowrap px-4 py-2 font-medium text-gray-900"
                                    >
                                        <?php echo e($message->name); ?>

                                    </td>
                                    <td
                                        class="whitespace-nowrap px-4 py-2 text-gray-700"
                                    >
                                        <?php echo e($message->getFormatDate()); ?> at
                                        <?php echo e($message->getFormatTime()); ?>

                                    </td>
                                    <td
                                        class="whitespace-nowrap px-4 py-2 text-gray-700"
                                    >
                                        <?php echo e($message->contact_email); ?>

                                    </td>
                                    <td
                                        data-bs-toggle="modal"
                                        data-bs-target="#<?php echo e($message->id); ?>"
                                        class="whitespace-nowrap px-4 py-2 text-gray-700"
                                    >
                                        <?php echo substr(html_entity_decode($message->message),
                                        0 ,10).".."; ?>

                                    </td>
                                    <!-- Modal -->
                                    <!-- <div
                                        class="modal fade"
                                        id="<?php echo e($message->id); ?>"
                                        tabindex="-1"
                                        aria-labelledby="exampleModalLabel"
                                        aria-hidden="true"
                                    >
                                        <div
                                            class="modal-dialog modal-dialog-scrollable modal-dialog-centered"
                                        >
                                            <div
                                                class="modal-content"
                                            >
                                                <div class="modal-header">
                                                    <button
                                                        type="button"
                                                        class="btn-close"
                                                        data-bs-dismiss="modal"
                                                        aria-label="Close"
                                                    >
                                                        X
                                                    </button>
                                                </div>
                                                <div
                                                    class="modal-body text-start"
                                                >
                                                    <?php echo html_entity_decode($message->message); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div> -->
                                    <div
                                        class="modal fade"
                                        id="<?php echo e($message->id); ?>"
                                        data-bs-backdrop="static"
                                        data-bs-keyboard="false"
                                        tabindex="-1"
                                        aria-labelledby="staticBackdropLabel"
                                        aria-hidden="true"
                                    >
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1
                                                        class="modal-title fs-5"
                                                        id="staticBackdropLabel"
                                                    >
                                                        <?php echo e($message->contact_email); ?>

                                                    </h1>
                                                    <button
                                                        type="button"
                                                        class="btn-close"
                                                        data-bs-dismiss="modal"
                                                        aria-label="Close"
                                                    >
                                                        X
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div>
                                                        <?php echo $message->message; ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\Laravel\innova-infosys-main\resources\views/dashboard.blade.php ENDPATH**/ ?>