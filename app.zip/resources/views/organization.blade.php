@extends('master.secondNav') @section('content')
<div id="organization" class="h-screen flex items-center">
    <div class="main max-w-screen-xl mx-auto p-5">
        <img
            class="w-full"
            src="{{ asset('/organization_structure/Structure.svg') }}"
            alt="Structure"
        />
    </div>
</div>
@endsection
