<?php

namespace App\Http\Controllers;



class CarrerController extends Controller
{
    //
    public function index()
    {
        return view('careers');
    }
}