
 
<?php $__env->startSection('content'); ?>
<div id="organization" class=" h-screen flex items-center">


    <div class="main max-w-screen-xl mx-auto p-5">
         <img class="w-full" src="<?php echo e(asset('/organization_structure/Structure.svg')); ?>" alt="Structure">
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.secondNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\innova-infosys-main\resources\views/organization.blade.php ENDPATH**/ ?>