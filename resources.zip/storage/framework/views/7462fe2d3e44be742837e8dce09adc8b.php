<div
    role="alert"
    class="rounded border-s-4 border-green-500 bg-green-50 p-4 mt-5"
>
    <div class="flex items-center gap-2 text-green-800">
        <strong class="block font-medium"> <?php echo e(session("status")); ?></strong>
    </div>
</div>
<?php /**PATH E:\Laravel\innova-infosys-main\resources\views/components/alert-success.blade.php ENDPATH**/ ?>